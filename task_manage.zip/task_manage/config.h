#ifndef CONFIG_H
#define CONFIG_H

#define GAME_WIDTH  800  //宽度
#define GAME_HEIGHT 600  //高度
#define GAME_TITLE "DDL 规划" //标题
#define GAME_ICON  ":/res/res/ddl.jpg"

#endif // CONFIG_H
