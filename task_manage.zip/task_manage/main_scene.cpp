#include "main_scene.h"
#include "ui_main_scene.h"
manage_task pax;

main_scene::main_scene(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::main_scene)
{
    ui->setupUi(this);
    initScene();
    connect(&son_task,SIGNAL(showMain()),this,SLOT(show_myself()));
}

main_scene::~main_scene()
{
    delete ui;
}

void main_scene::on_pushButton_clicked()
{
    this->hide();
    son_task.show();
}

void main_scene::show_myself()
{
    this->show();
}

void main_scene::initScene()
{
    setFixedSize(GAME_WIDTH,GAME_HEIGHT);
    setWindowTitle(GAME_TITLE);
    setWindowIcon(QIcon( GAME_ICON));
}

void main_scene::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QStyleOption opt;
    opt.initFrom(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
    setStyleSheet("background-color: rgb(196,230,255);");
}
